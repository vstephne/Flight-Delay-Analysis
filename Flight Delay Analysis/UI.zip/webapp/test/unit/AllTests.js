sap.ui.define([
	"FlightDelay/FlightDelay/test/unit/controller/View1.controller"
], function () {
	"use strict";
});