sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageToast",
	"sap/ui/model/json/JSONModel"
], function (Controller, MessageToast, JSONModel) {
	"use strict";
	var Airport;
	var FlightNoYear;
	return Controller.extend("FlightDelay.FlightDelay.controller.Airport", {

		onInit: function () {
			var oThis = this;

			// oThis.setLineWeather();
			// oThis.setLineSecurity();
			// oThis.setLineArrival();
			// oThis.setLineDeparture();
			// oThis.setColumnDelay();
			oThis.setComboBox();
			oThis.setComboBoxYear();
			// oThis.onComboBoxItem();

		},
		setComboBox: function (oEvent) {
			var oThis = this;
			var oLine = oThis.byId("AirportComboBox");
			var sampleDatajson = new sap.ui.model.json.JSONModel("model/Airport.json");
			oLine.setModel(sampleDatajson);
			//	var SelectedText = this.combobox.SelectionBoxItem.ToString();
			//	console.log(SelectedText);

		},
		onComboBoxItem: function (oEvent) {
			var oThis = this;
			// var itemText = oEvent.getParameter("selectedItem").getText();
			var itemText = this.byId("AirportComboBox").getSelectedItem().getText();
			var FlightCombo = this.byId("FlightComboBox");
			Airport = itemText;
			console.log(itemText);

			var temp = "";
			temp = "http\://";
			var uri = "http://127.0.0.1:5000/getFlightsAir";

			jQuery.ajax({
				url: uri,

				// dataType: "json",
				type: "GET",
				data: "airport=" + itemText,
				headers: {
					'Access-Control-Allow-Origin': '*'
				},
				//data : oModel.getData(),
				success: function (data) {
					//console.log(data);
					sap.m.MessageToast.show("worked fine");
					// var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
					// oRouter.navTo("RouteView");   
					var sampleDatajson = new sap.ui.model.json.JSONModel(data);
					FlightCombo.setModel(sampleDatajson);

				},
				error: function (err) {
					sap.m.MessageToast.show("Error is Encountered", err);
				}
			});

		},
		onComboBoxFlight: function () {
			var oThis = this;
			var FlightNo = this.byId("FlightComboBox").getSelectedItem().getText();
			var oLine = oThis.byId("idVizFrameYearDelay");

			var temp = "";
			temp = "http\://";
			var uri = "http://127.0.0.1:5000/sumDelayAF";

			jQuery.ajax({
				url: uri,

				// dataType: "json",
				type: "GET",
				data: "airport=" + Airport + "&flight=" + FlightNo,
				headers: {
					'Access-Control-Allow-Origin': '*'
				},
				//data : oModel.getData(),
				success: function (data) {
					//console.log(data);
					sap.m.MessageToast.show("worked fine");
					// var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
					// oRouter.navTo("RouteView");   
					var sampleDatajson = new sap.ui.model.json.JSONModel(data);
					oLine.setModel(sampleDatajson);
				},
				error: function (err) {
					sap.m.MessageToast.show("Error is Encountered", err);
				}
			});
		},
		setComboBoxYear: function () {
			var oThis = this;
			var oLine = oThis.byId("AirportComboBoxYear");
			var sampleDatajson = new sap.ui.model.json.JSONModel("model/Airport.json");
			oLine.setModel(sampleDatajson);
			var oYear = oThis.byId("YearComboBox");
			var sampleData = new sap.ui.model.json.JSONModel("model/Year.json");
			oYear.setModel(sampleData);
		},
		onComboBoxItemYear: function () {
			var oThis = this;
			// var itemText = oEvent.getParameter("selectedItem").getText();
			var itemText = this.byId("AirportComboBoxYear").getSelectedItem().getText();
			var FlightCombo = this.byId("FlightComboBoxYear");
			Airport = itemText;
			console.log(itemText);

			var temp = "";
			temp = "http\://";
			var uri = "http://127.0.0.1:5000/getFlightsAir";

			jQuery.ajax({
				url: uri,

				// dataType: "json",
				type: "GET",
				data: "airport=" + itemText,
				headers: {
					'Access-Control-Allow-Origin': '*'
				},
				//data : oModel.getData(),
				success: function (data) {
					//console.log(data);
					sap.m.MessageToast.show("worked fine");
					// var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
					// oRouter.navTo("RouteView");   
					var sampleDatajson = new sap.ui.model.json.JSONModel(data);
					FlightCombo.setModel(sampleDatajson);

				},
				error: function (err) {
					sap.m.MessageToast.show("Error is Encountered", err);
				}
			});
		},
		onComboBoxFlightYear: function () {
			var oThis = this;
			var FlightNo = this.byId("FlightComboBoxYear").getSelectedItem().getText();
			// var oLine = oThis.byId("idVizFrameYearDelay");
			FlightNoYear = FlightNo;
			var temp = "";
			temp = "http\://";
			var uri = "http://127.0.0.1:5000/sumDelayAF";

			jQuery.ajax({
				url: uri,

				// dataType: "json",
				type: "GET",
				data: "airport=" + Airport + "&flight=" + FlightNo,
				headers: {
					'Access-Control-Allow-Origin': '*'
				},
				//data : oModel.getData(),
				success: function (data) {
					//console.log(data);
					sap.m.MessageToast.show("worked fine");
					// var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
					// oRouter.navTo("RouteView");   
					var sampleDatajson = new sap.ui.model.json.JSONModel(data);
					oLine.setModel(sampleDatajson);
				},
				error: function (err) {
					sap.m.MessageToast.show("Error is Encountered", err);
				}
			});
		},
		onComboBoxYear: function () {
			var Year = this.byId("YearComboBox").getSelectedItem().getText();
			var temp = "";
			temp = "http\://";
			var uri = "http://127.0.0.1:5000/sumDelayAFY";
			var oGraph = this.byId("idVizFrameYear");

			jQuery.ajax({
				url: uri,

				// dataType: "json",
				type: "GET",
				data: "airport=" + Airport + "&flight=" + FlightNoYear + "&year=" + Year,
				headers: {
					'Access-Control-Allow-Origin': '*'
				},
				//data : oModel.getData(),
				success: function (data) {
					//console.log(data);
					sap.m.MessageToast.show("worked fine");
					// var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
					// oRouter.navTo("RouteView");   
					var sampleDatajson = new sap.ui.model.json.JSONModel(data);
					oGraph.setModel(sampleDatajson);
				},
				error: function (err) {
					sap.m.MessageToast.show("Error is Encountered", err);
				}
			});
		},

		setLineWeather: function () {
			var oThis = this;
			var oLine = oThis.byId("idVizFrameYearDelay");

			var temp = "";
			temp = "http\://";
			var uri = "http://127.0.0.1:5000/sumDelayAF";

			jQuery.ajax({
				url: uri,

				// dataType: "json",
				type: "GET",
				data: "airport=",
				headers: {
					'Access-Control-Allow-Origin': '*'
				},
				//data : oModel.getData(),
				success: function (data) {
					//console.log(data);
					sap.m.MessageToast.show("worked fine");
					// var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
					// oRouter.navTo("RouteView");   
					var sampleDatajson = new sap.ui.model.json.JSONModel(data);
					oLine.setModel(sampleDatajson);
				},
				error: function (err) {
					sap.m.MessageToast.show("Error is Encountered", err);
				}
			});
		},
		setLineSecurity: function () {
			var oThis = this;
			var oLine = oThis.byId("idVizFrameSecurity");

			var temp = "";
			temp = "http\://";
			var uri = "http://127.0.0.1:5000/CSecurityYearDelay";

			jQuery.ajax({
				url: uri,

				// dataType: "json",
				type: "GET",
				data: "year=2015",
				headers: {
					'Access-Control-Allow-Origin': '*'
				},
				//data : oModel.getData(),
				success: function (data) {
					//console.log(data);
					sap.m.MessageToast.show("worked fine");
					// var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
					// oRouter.navTo("RouteView");   
					var sampleDatajson = new sap.ui.model.json.JSONModel(data);
					oLine.setModel(sampleDatajson);
				},
				error: function (err) {
					sap.m.MessageToast.show("Error is Encountered", err);
				}
			});
		},
		setLineArrival: function () {
			var oThis = this;
			var oLine = oThis.byId("idVizFrameArrival");

			var temp = "";
			temp = "http\://";
			var uri = "http://127.0.0.1:5000/CArrivalYearDelay";

			jQuery.ajax({
				url: uri,

				// dataType: "json",
				type: "GET",
				data: "year=2015",
				headers: {
					'Access-Control-Allow-Origin': '*'
				},
				//data : oModel.getData(),
				success: function (data) {
					//console.log(data);
					sap.m.MessageToast.show("worked fine");
					// var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
					// oRouter.navTo("RouteView");   
					var sampleDatajson = new sap.ui.model.json.JSONModel(data);
					oLine.setModel(sampleDatajson);
				},
				error: function (err) {
					sap.m.MessageToast.show("Error is Encountered", err);
				}
			});
		},
		setLineDeparture: function () {
			var oThis = this;
			var oLine = oThis.byId("idVizFrameDeparture");

			var temp = "";
			temp = "http\://";
			var uri = "http://127.0.0.1:5000/CDepartureYearDelay";

			jQuery.ajax({
				url: uri,

				// dataType: "json",
				type: "GET",
				data: "year=2015",
				headers: {
					'Access-Control-Allow-Origin': '*'
				},
				//data : oModel.getData(),
				success: function (data) {
					//console.log(data);
					sap.m.MessageToast.show("worked fine");
					// var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
					// oRouter.navTo("RouteView");   
					var sampleDatajson = new sap.ui.model.json.JSONModel(data);
					oLine.setModel(sampleDatajson);
				},
				error: function (err) {
					sap.m.MessageToast.show("Error is Encountered", err);
				}
			});
		},
		setColumnDelay: function () {
			var oThis = this;
			var oLine = oThis.byId("idVizFrameYearDelay");
			var oLabel = oThis.byId("LabelTotal");
			var parameter = "year_delay";

			var temp = "";
			temp = "http\://";
			var uri = "http://127.0.0.1:5000/sumDelayYear";

			jQuery.ajax({
				url: uri,
				data: "year=2015",
				// dataType: "json",
				type: "GET",

				headers: {
					'Access-Control-Allow-Origin': '*'
				},
				//data : oModel.getData(),
				success: function (data) {
					//console.log(data);
					sap.m.MessageToast.show("worked fine");
					// var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
					// oRouter.navTo("RouteView");   
					var sampleDatajson = new sap.ui.model.json.JSONModel(data);
					oLine.setModel(sampleDatajson);
					oLabel.setModel(sampleDatajson);
				},
				error: function (err) {
					sap.m.MessageToast.show("Error is Encountered", err);
				}
			});
		}

	});
});