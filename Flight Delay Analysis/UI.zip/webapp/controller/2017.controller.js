sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageToast",
	"sap/ui/model/json/JSONModel"
], function (Controller, MessageToast, JSONModel) {
	"use strict";

	return Controller.extend("FlightDelay.FlightDelay.controller.2017", {

		onInit: function () {
			var oThis = this;

			oThis.setLineWeather();
			oThis.setLineSecurity();
			oThis.setLineArrival();
			oThis.setLineDeparture();
			oThis.setColumnDelay();
			//oThis.setComboBox();
			// oThis.onComboBoxItem();

		},
		setComboBox: function (oEvent) {
			var oThis = this;
			var oLine = oThis.byId("AirportComboBox");
			var sampleDatajson = new sap.ui.model.json.JSONModel("model/Airport.json");
			oLine.setModel(sampleDatajson);
			//	var SelectedText = this.combobox.SelectionBoxItem.ToString();
			//	console.log(SelectedText);

		},
		onComboBoxItem: function (oEvent) {
			//	var itemText = oEvent.getParameter("selectedItem").getText();
			var itemText = this.byId("FlightComboBox").getSelectedItems();
			console.log(itemText);
			var oLine = oThis.byId("FlightComboBox");
			var temp = "";
			temp = "http\://";
			var uri = "http://127.0.0.1:5000/getFlightsAir";

			jQuery.ajax({
				url: uri,

				// dataType: "json",
				type: "GET",
				data: JSON.stringify(itemText),
				headers: {
					'Access-Control-Allow-Origin': '*'
				},
				//data : oModel.getData(),
				success: function (data) {
					//console.log(data);
					sap.m.MessageToast.show("worked fine");
					// var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
					// oRouter.navTo("RouteView");   
					var sampleDatajson = new sap.ui.model.json.JSONModel(data);
					oLine.setModel(sampleDatajson);
				},
				error: function (err) {
					sap.m.MessageToast.show("Error is Encountered", err);
				}
			});

		},
		setLineWeather: function () {
			var oThis = this;
			var oLine = oThis.byId("idVizFrameWeather");

			var temp = "";
			temp = "http\://";
			var uri = "http://127.0.0.1:5000/CWeatherYearDelay";

			jQuery.ajax({
				url: uri,

				// dataType: "json",
				type: "GET",
				data: "year=2017",
				headers: {
					'Access-Control-Allow-Origin': '*'
				},
				//data : oModel.getData(),
				success: function (data) {
					//console.log(data);
					sap.m.MessageToast.show("worked fine");
					// var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
					// oRouter.navTo("RouteView");   
					var sampleDatajson = new sap.ui.model.json.JSONModel(data);
					oLine.setModel(sampleDatajson);
				},
				error: function (err) {
					sap.m.MessageToast.show("Error is Encountered", err);
				}
			});
		},
		setLineSecurity: function () {
			var oThis = this;
			var oLine = oThis.byId("idVizFrameSecurity");

			var temp = "";
			temp = "http\://";
			var uri = "http://127.0.0.1:5000/CSecurityYearDelay";

			jQuery.ajax({
				url: uri,

				// dataType: "json",
				type: "GET",
				data: "year=2017",
				headers: {
					'Access-Control-Allow-Origin': '*'
				},
				//data : oModel.getData(),
				success: function (data) {
					//console.log(data);
					sap.m.MessageToast.show("worked fine");
					// var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
					// oRouter.navTo("RouteView");   
					var sampleDatajson = new sap.ui.model.json.JSONModel(data);
					oLine.setModel(sampleDatajson);
				},
				error: function (err) {
					sap.m.MessageToast.show("Error is Encountered", err);
				}
			});
		},
		setLineArrival: function () {
			var oThis = this;
			var oLine = oThis.byId("idVizFrameArrival");

			var temp = "";
			temp = "http\://";
			var uri = "http://127.0.0.1:5000/CArrivalYearDelay";

			jQuery.ajax({
				url: uri,

				// dataType: "json",
				type: "GET",
				data: "year=2017",
				headers: {
					'Access-Control-Allow-Origin': '*'
				},
				//data : oModel.getData(),
				success: function (data) {
					//console.log(data);
					sap.m.MessageToast.show("worked fine");
					// var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
					// oRouter.navTo("RouteView");   
					var sampleDatajson = new sap.ui.model.json.JSONModel(data);
					oLine.setModel(sampleDatajson);
				},
				error: function (err) {
					sap.m.MessageToast.show("Error is Encountered", err);
				}
			});
		},
		setLineDeparture: function () {
			var oThis = this;
			var oLine = oThis.byId("idVizFrameDeparture");

			var temp = "";
			temp = "http\://";
			var uri = "http://127.0.0.1:5000/CDepartureYearDelay";

			jQuery.ajax({
				url: uri,

				// dataType: "json",
				type: "GET",
				data: "year=2017",
				headers: {
					'Access-Control-Allow-Origin': '*'
				},
				//data : oModel.getData(),
				success: function (data) {
					//console.log(data);
					sap.m.MessageToast.show("worked fine");
					// var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
					// oRouter.navTo("RouteView");   
					var sampleDatajson = new sap.ui.model.json.JSONModel(data);
					oLine.setModel(sampleDatajson);
				},
				error: function (err) {
					sap.m.MessageToast.show("Error is Encountered", err);
				}
			});
		},
		setColumnDelay: function () {
			var oThis = this;
			var oLine = oThis.byId("idVizFrameYearDelay");
			var oLabel = oThis.byId("LabelTotal");
			var parameter = "year_delay";

			var temp = "";
			temp = "http\://";
			var uri = "http://127.0.0.1:5000/sumDelayYear";

			jQuery.ajax({
				url: uri,
				data: "year=2017",
				// dataType: "json",
				type: "GET",

				headers: {
					'Access-Control-Allow-Origin': '*'
				},
				//data : oModel.getData(),
				success: function (data) {
					//console.log(data);
					sap.m.MessageToast.show("worked fine");
					// var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
					// oRouter.navTo("RouteView");   
					var sampleDatajson = new sap.ui.model.json.JSONModel(data);
					oLine.setModel(sampleDatajson);
					oLabel.setModel(sampleDatajson);
				},
				error: function (err) {
					sap.m.MessageToast.show("Error is Encountered", err);
				}
			});
		}

	});
});