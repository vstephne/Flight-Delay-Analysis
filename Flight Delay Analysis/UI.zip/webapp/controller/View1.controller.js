sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageToast",
	"sap/ui/model/json/JSONModel"
], function (Controller, MessageToast, JSONModel) {
	"use strict";

	return Controller.extend("FlightDelay.FlightDelay.controller.View1", {
		onInit: function () {

		},
		onItemSelect: function (oEvent) {
			var oItem = oEvent.getParameter("item");
			var sKey = oItem.getKey();
			// if you click on home, settings or statistics button, call the navTo function
			if ((sKey === "home" || sKey === "2015" || sKey === "Time" || sKey === "Airport" || sKey === "2016" || sKey === "2017" || sKey ===
					"2018" || sKey === "2019")) {
				// if the device is phone, collaps the navigation side of the app to give more space
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo(sKey);

			} else {
				MessageToast.show(sKey);
			}
		}
	});
});