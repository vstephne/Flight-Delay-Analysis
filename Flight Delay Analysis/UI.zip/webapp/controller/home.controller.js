sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageToast",
	"sap/ui/model/json/JSONModel"
], function (Controller, MessageToast, JSONModel) {
	"use strict";

	return Controller.extend("FlightDelay.FlightDelay.controller.home", {

		onInit: function () {
			var oThis = this;

			oThis.setLineWeather();
			oThis.setLineSecurity();
			oThis.setLineArrival();
			oThis.setLineDeparture();
			// oThis.setLineYear();
			// oThis.setLineMonth();
			oThis.setLineMonthDelay();

		},
		setLineWeather: function () {
			var oThis = this;
			var oLine = oThis.byId("idVizFrameWeather");

			var temp = "";
			temp = "http\://";
			var uri = "http://127.0.0.1:5000/weatherDelay";

			jQuery.ajax({
				url: uri,

				// dataType: "json",
				type: "GET",
				//	data: JSON.stringify("weather"),
				headers: {
					'Access-Control-Allow-Origin': '*'
				},
				//data : oModel.getData(),
				success: function (data) {
					//console.log(data);
					sap.m.MessageToast.show("worked fine");
					// var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
					// oRouter.navTo("RouteView");   
					var sampleDatajson = new sap.ui.model.json.JSONModel(data);
					oLine.setModel(sampleDatajson);
				},
				error: function (err) {
					sap.m.MessageToast.show("Error is Encountered", err);
				}
			});
		},
		setLineSecurity: function () {
			var oThis = this;
			var oLine = oThis.byId("idVizFrameSecurity");

			var temp = "";
			temp = "http\://";
			var uri = "http://127.0.0.1:5000/securityDelay";

			jQuery.ajax({
				url: uri,

				// dataType: "json",
				type: "GET",
				data: JSON.stringify("security"),
				headers: {
					'Access-Control-Allow-Origin': '*'
				},
				//data : oModel.getData(),
				success: function (data) {
					//console.log(data);
					sap.m.MessageToast.show("worked fine");
					// var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
					// oRouter.navTo("RouteView");   
					var sampleDatajson = new sap.ui.model.json.JSONModel(data);
					oLine.setModel(sampleDatajson);
				},
				error: function (err) {
					sap.m.MessageToast.show("Error is Encountered", err);
				}
			});
		},
		setLineArrival: function () {
			var oThis = this;
			var oLine = oThis.byId("idVizFrameArrival");

			var temp = "";
			temp = "http\://";
			var uri = "http://127.0.0.1:5000/arrivalDelay";

			jQuery.ajax({
				url: uri,

				// dataType: "json",
				type: "GET",
				data: JSON.stringify("arrival"),
				headers: {
					'Access-Control-Allow-Origin': '*'
				},
				//data : oModel.getData(),
				success: function (data) {
					//console.log(data);
					sap.m.MessageToast.show("worked fine");
					// var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
					// oRouter.navTo("RouteView");   
					var sampleDatajson = new sap.ui.model.json.JSONModel(data);
					oLine.setModel(sampleDatajson);
				},
				error: function (err) {
					sap.m.MessageToast.show("Error is Encountered", err);
				}
			});
		},
		setLineDeparture: function () {
			var oThis = this;
			var oLine = oThis.byId("idVizFrameDeparture");
			var parameter = "department";

			var temp = "";
			temp = "http\://";
			var uri = "http://127.0.0.1:5000/departureDelay";

			jQuery.ajax({
				url: uri,

				// dataType: "json",
				type: "GET",
				data: JSON.stringify(parameter),
				headers: {
					'Access-Control-Allow-Origin': '*'
				},
				//data : oModel.getData(),
				success: function (data) {
					//console.log(data);
					sap.m.MessageToast.show("worked fine");
					// var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
					// oRouter.navTo("RouteView");   
					var sampleDatajson = new sap.ui.model.json.JSONModel(data);
					oLine.setModel(sampleDatajson);
				},
				error: function (err) {
					sap.m.MessageToast.show("Error is Encountered", err);
				}
			});
		},
		// setLineYear: function () {
		// 	var oThis = this;
		// 	var oLine = oThis.byId("idVizFrameYear");
		// 	var parameter = "year_delay";

		// 	var temp = "";
		// 	temp = "http\://";
		// 	var uri = "http://127.0.0.1:5000/time_delay";
		// 	// $.ajax({
		// 	// 	type: "POST",
		// 	// 	dataType: "json",
		// 	// 	url: uri,
		// 	// 	cors: true,
		// 	// 	secure: true,
		// 	// 	// headers: {
		// 	// 	// 	'Access-Control-Allow-Origin': '*'
		// 	// 	// },
		// 	// 	success: function (data, textStatus, jqXHR) {
		// 	// 		var sampleDatajson = new sap.ui.model.json.JSONModel(data);
		// 	// 		oLine.setModel(sampleDatajson);
		// 	// 		oThis.getView().setBusy(false);
		// 	// 	}
		// 	// });
		// 	jQuery.ajax({
		// 		url: uri,

		// 		// dataType: "json",
		// 		type: "POST",
		// 		data: JSON.stringify(parameter),
		// 		headers: {
		// 			'Access-Control-Allow-Origin': '*'
		// 		},
		// 		//data : oModel.getData(),
		// 		success: function (data) {
		// 			//console.log(data);
		// 			sap.m.MessageToast.show("worked fine");
		// 			// var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
		// 			// oRouter.navTo("RouteView");   
		// 			var sampleDatajson = new sap.ui.model.json.JSONModel(data);
		// 			oLine.setModel(sampleDatajson);
		// 		},
		// 		error: function (err) {
		// 			sap.m.MessageToast.show("Error is Encountered", err);
		// 		}
		// 	});
		// },
		// setLineMonth: function () {
		// 	var oThis = this;
		// 	var oLine = oThis.byId("idVizFrameMonth");
		// 	var parameter = "month_delay";

		// 	var temp = "";
		// 	temp = "http\://";
		// 	var uri = "http://127.0.0.1:5000/CDeparturemonthDelay";

		// 	jQuery.ajax({
		// 		url: uri,

		// 		// dataType: "json",
		// 		type: "GET",
		// 		data: "",
		// 		headers: {
		// 			'Access-Control-Allow-Origin': '*'
		// 		},
		// 		//data : oModel.getData(),
		// 		success: function (data) {
		// 			//console.log(data);
		// 			sap.m.MessageToast.show("worked fine");
		// 			// var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
		// 			// oRouter.navTo("RouteView");   
		// 			var sampleDatajson = new sap.ui.model.json.JSONModel(data);
		// 			oLine.setModel(sampleDatajson);
		// 		},
		// 		error: function (err) {
		// 			sap.m.MessageToast.show("Error is Encountered", err);
		// 		}
		// 	});
		// },
		setLineMonthDelay: function () {
			var oThis = this;
			var oLine = oThis.byId("idVizFrameMonthDelay");

			var sampleDatajson = new sap.ui.model.json.JSONModel("model/Month.json");
			oLine.setModel(sampleDatajson);

		}
	});
});